public class Main {
    public static void main(String[] args) {
        Pilha pilha = new Pilha(10);

        pilha.push(10);
        pilha.push(10);
        pilha.pop();
        pilha.print();
    }
}
